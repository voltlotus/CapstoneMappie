//
//  ViewController.swift
//  CapstoneProject(Mappi)
//
//  Created by hayden rusk on 10/16/16.
//  Copyright © 2016 BSUCS320. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation



class ViewController: UIViewController, MKMapViewDelegate, CLLocationManagerDelegate {

    
    func UpdateUserLocation() {
    
        print("Updated Location")
        
        locationManager.startUpdatingLocation()
        //sleep(1)
        //latestLocation = (locationManager.location?.coordinate)!
        
        GPSMapView.showsUserLocation = true
        
        locationManager.stopUpdatingLocation()
        
        let newLatitude: Float = Float(latitude_text)! //
        let newLongitude: Float = Float(longitude_text)!
             
        let location = CLLocationCoordinate2D(latitude: CLLocationDegrees(newLatitude), longitude: CLLocationDegrees(newLongitude))
        let span = MKCoordinateSpanMake(0.01, 0.01)
        let region = MKCoordinateRegion(center: location, span:span)
        GPSMapView.setRegion(region, animated: true)
        GPSMapView.showsUserLocation = true
        
        
    }
    var locationManager: CLLocationManager = CLLocationManager()
    @IBOutlet weak var GPSMapView: MKMapView!
    
    var startLocation: CLLocation!
    
    var longitude_text = ""
    var latitude_text = ""
    
    
    var userLatitude = 40.20370
    var userLongitude = -85.40797
    
 
    let bellTowerAnnotation = MKPointAnnotation()
    
    
    let ballTower = LocationClass(locationName: "Ball Tower", latitude: 40.20370, longitude: -85.40797, description: "BSU", trivia: "idk bells and stuff", guidedTour: 1)
    let library = LocationClass(locationName: "Bracken Library", latitude: 40.203200, longitude: -85.40647,description: "BSU",trivia: "where this app was made woooooo",guidedTour: 2)
    
    let studentCent = LocationClass(locationName: "Student Center", latitude: 40.1971, longitude: -85.4089, description: "BSU", trivia: "every saturday night there is a school party called 'Late Night' held here",guidedTour: 3)
    
    
    var locationList: [LocationClass] = []
    
    
    var pinList: [PinClass] = []
    
    
    
    @IBOutlet weak var LocationLabel: UILabel!
    
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
       
        
        
        self.GPSMapView.delegate = self
        
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.delegate = self
        locationManager.requestWhenInUseAuthorization()
        locationManager.startUpdatingLocation()
        //startLocation = nil
        
        
        let location = CLLocationCoordinate2D(latitude: userLatitude, longitude: userLongitude)
        let span = MKCoordinateSpanMake(0.01, 0.01)
        let region = MKCoordinateRegion(center: location, span:span)
        GPSMapView.setRegion(region, animated: true)
        GPSMapView.showsUserLocation = true
        
        
        locationList.append(ballTower)
        locationList.append(library)
        locationList.append(studentCent)
        
       
        for index in locationList{
           
            var coordinate = CLLocationCoordinate2D(latitude: index.latitude, longitude: index.longitude)
            
            var pin = PinClass(coordinate: coordinate, name: index.location, desc: index.description, trivia: index.trivia, guidedTour: index.guidedTour)
            
            pinList.append(pin)
            GPSMapView.addAnnotation(pin.makeAnnotation())
        }
        
        
        
        let backGroud = DispatchQueue(label: "com.app.queue", qos: .background,target: nil)
        backGroud.async {
            
           
            if(self.TourType == 1){
                
                self.freeRoamTourFunction()
            }else if(self.TourType == 2){
             
                self.guidedTourFunction()
            }
            else{
                print ("error")
            }
            
            
            
        }
        //let backGroudTimer = DispatchQueue(label: "com.app.queue", qos: .background,target: nil)
        //backGroudTimer.async {
            //---------------------------------------------------------------------
            var updateTimer = Timer.scheduledTimer(timeInterval: 15.0, target: self, selector: "UpdateUserLocation", userInfo: nil, repeats: true)
            //---------------------------------------------------------------------
        //}
       
        //parser()
    }
    
    
    
    var TourType: Int = 0
    
    var rangeVariable = 0.0001
    
    func freeRoamTourFunction(){
        
        LocationLabel.text = "Free Roam Mode"
        sleep(5)
        print("----")
        print(self.locationList.count)
        print(latestLocation.latitude)
        print("- -")
        
        var index = 1

        while(index <= self.locationList.count){
            
            
            if((latestLocation.latitude - ballTower.latitude <= rangeVariable) && (latestLocation.longitude - ballTower.longitude <= rangeVariable) ){
                index += 1
                
                self.LocationLabel.text = "You have reached the BellTower"
                
                
            }else if((latestLocation.latitude - library.latitude <= rangeVariable) && (latestLocation.longitude - library.longitude <= rangeVariable)){
                index += 1
                
                self.LocationLabel.text = "You have reached the Library"
                
            }else if((latestLocation.latitude - studentCent.latitude <= rangeVariable) && (latestLocation.longitude - studentCent.longitude <= rangeVariable)){
                index += 1
                
                self.LocationLabel.text = "You have reached the Student Center"
               
            }
            sleep(15)
   
        }

    }
    
    
    
    func guidedTourFunction(){
        
        let size = locationList.count
        
        LocationLabel.text = "Head to the BellTower"
        sleep(5)
        print("----")
        print(self.locationList.count)
        print(latestLocation.latitude)
        print("- -")
        
        
        var index = 1
        
            
            
            while(index <= self.locationList.count){
                
                
                if((self.latestLocation.latitude - self.ballTower.latitude <= rangeVariable) && (self.latestLocation.longitude - self.ballTower.longitude <= rangeVariable) ){
                    index += 1
                    
                    self.LocationLabel.text = "You have reached the BellTower"
                    sleep(10)
                    self.LocationLabel.text = "Head to the Library"
                    
                }else if((self.latestLocation.latitude - self.library.latitude <= rangeVariable) && (self.latestLocation.longitude - self.library.longitude <= rangeVariable)){
                    index += 1
                    
                    self.LocationLabel.text = "You have reached the Library"
                    sleep(10)
                    self.LocationLabel.text = "Head to the Student Center"
                }else if((self.latestLocation.latitude - self.studentCent.latitude <= rangeVariable) && (self.latestLocation.longitude - self.studentCent.longitude <= rangeVariable)){
                    index += 1
                    
                    self.LocationLabel.text = "You have reached the Student Center"
                    sleep(10)
                    self.LocationLabel.text = "You have finished the Tour!"
                }
                sleep(15)
                
                
                
                
            
        }
        
    }
    

    
    
    
    var latestLocation: CLLocationCoordinate2D = CLLocationCoordinate2D()
    func locationManager(_ manager: CLLocationManager!, didUpdateLocations locations: [CLLocation]!){
   // func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]){
    //var locValue: CLLocationCoordinate2D = manager.location!.coordinate
    //print("locations = " )
    //print(locValue.latitude)
    //print(locValue.longitude)
        
        
        //latestLocation = locations[locations.count - 1]
        print("eaddd")
        print(latestLocation.latitude)
        print(latestLocation.longitude)
        
        latitude_text = String(format: "%.4f", latestLocation.latitude)
        longitude_text = String(format: "%.4f", latestLocation.longitude)
        
        //print(latitude_text)
        //print(longitude_text)
        
        
        if startLocation == nil{
           startLocation = latestLocation as! CLLocation
        }
        
    }
    
    func locationManager(_ manager: CLLocationManager, didfailWithError error: Error){
        print(error.localizedDescription)
    }
    
    
    func mapView(_ mapView: MKMapView!, viewFor annotation: MKAnnotation!) -> MKAnnotationView!{
        
        let identifier = "BallState Bell Tower"
        var view: MKPinAnnotationView
        if let dequeuedView = mapView.dequeueReusableAnnotationView(withIdentifier: identifier) as? MKPinAnnotationView{
            dequeuedView.annotation = annotation
            view = dequeuedView
        }else{
            view = MKPinAnnotationView(annotation: annotation, reuseIdentifier: identifier)
            view.canShowCallout = true
            view.calloutOffset = CGPoint(x: -5, y: 5)
            let button = (UIButton(type: .detailDisclosure))
            button.isHidden = true
            let buttonView = button as UIView
            view.rightCalloutAccessoryView = buttonView
            
            
        }
        return view
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any!) {
        if (segue.identifier == "BellTowerSegue") {
             let dest = segue.destination as! DestinationViewController
                dest.Location = selectedLocation
        }

    }
    var selectedLocation: PinClass!
    
    func mapView(_ mapView: MKMapView, annotationView view: MKAnnotationView, calloutAccessoryControlTapped control: UIControl){
        if control == view.rightCalloutAccessoryView{
            for index in pinList{
                if(index.makeAnnotation().title == (view.annotation?.title)!){
                    selectedLocation = index
                }
            }
            
            self.performSegue(withIdentifier: "BellTowerSegue", sender: self)
            
        }
        
         print("---button success---")
    }
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    func parser(){
    
    //let urlAsString = "https://itunes.apple.com/search?term=\(search)&entity=\(entityTxt)"
        let urlAsString = "https://docs.google.com/spreadsheets/d/1Q1EE8aULP4ZQaQrvq3IatJAjiPhOPuGTXH7TUdTvor4/gviz/tq?tqx=out:json&tq&gid=0"
        print (urlAsString)
        let url = URL(string: urlAsString)
        let urlSession = URLSession.shared
        let task = urlSession.dataTask(with: url!, completionHandler: {data, response, error -> Void in
            print("Task completed")
        
            if (error != nil){
                print(error!.localizedDescription)
            
            }
            do{
                if let jsonResult = try JSONSerialization.jsonObject(with: data!, options: JSONSerialization.ReadingOptions.mutableContainers) as? NSDictionary{
                
                    
                
                }
            }
            
            catch{}
        
        })
    
        task.resume()
        sleep(2)
        //self.infoTabelView.reloadData()
    
    
}






}

