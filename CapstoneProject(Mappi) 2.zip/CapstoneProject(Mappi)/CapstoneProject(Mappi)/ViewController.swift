//
//  ViewController.swift
//  CapstoneProject(Mappi)
//
//  Created by hayden rusk on 10/16/16.
//  Copyright © 2016 BSUCS320. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation



class ViewController: UIViewController, MKMapViewDelegate, CLLocationManagerDelegate {
    
//=====================================VARIABLES=================================
    var latestLocation: CLLocationCoordinate2D = CLLocationCoordinate2D()
    
    var selectedLocation: PinClass!
    
    @IBOutlet weak var tourInfoLabel: UITextView!
    
    var continues = false // Have not clicked to go to the detailed view controller yet
    var back = false // this is whether the back button was pushed or not (stops tours)
    
    var destPin = PinClass()
    
    var TourType = 0
    var backGround = DispatchQueue(label: "com.app.queue", qos: .background,target: nil)
    
    @IBOutlet weak var GPSMapView: MKMapView!
    
    var locationManager: CLLocationManager = CLLocationManager()
    var startLocation: CLLocation!
    
    var longitude_text = ""
    var latitude_text = ""
    
    var userLatitude = 40.20370
    var userLongitude = -85.40797
    
    let bellTowerAnnotation = MKPointAnnotation()
    
    
    var ballTower = LocationClass()
    var library = LocationClass()
    var studentCenter = LocationClass()
    
    
    var locationList: [LocationClass] = []
    
    var pinList: [PinClass] = []
    
    var updateLocationTimer: Timer = Timer()
    
//=====================================VARIABLES=================================
    
//=====================================VIEW DID LOAD=================================
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationItem.hidesBackButton = true
        let newBackButton = UIBarButtonItem( title: "Back", style: UIBarButtonItemStyle.plain, target: self, action: #selector(ViewController.back(sender: )))
        self.navigationItem.leftBarButtonItem = newBackButton
        
        
        UpdateUserLocation()
        
        //Commnet out when running for real
        
        //latestLocation = CLLocationCoordinate2DMake(CLLocationDegrees(40.202424), CLLocationDegrees(-85.407116))
        
        //Commnet out when running for real
        
        
        /*ballTower.locationName = "Ball Tower"
        ballTower.latitude = 40.20370
        ballTower.longitude = -85.40797
        ballTower.locationSubName = "BSU"
        ballTower.trivia = "idk bells and stuff"
        
        library.locationName = "Bracken Library"
        library.latitude = 40.203200
        library.longitude = -85.40647
        library.locationSubName = "BSU"
        library.trivia = "where this app was made woooooo"
        
        studentCenter.locationName = "Student Center"
        studentCenter.latitude = 40.1971
        studentCenter.longitude = -85.4089
        studentCenter.locationSubName = "BSU"
        studentCenter.trivia = "Has Late night every saturday night"
        */
        
        
        
        //====================================TIMER================================
        //updateLocationTimer = Timer.scheduledTimer(timeInterval: 15.0, target: self, selector: #selector(ViewController.UpdateUserLocation), userInfo: nil, repeats: true)
        //====================================TIMER================================
        
        self.GPSMapView.delegate = self
        
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.delegate = self
        locationManager.requestWhenInUseAuthorization()
        locationManager.startUpdatingLocation()
        //startLocation = nil
        
        
        let location = CLLocationCoordinate2D(latitude: userLatitude, longitude: userLongitude)
        let span = MKCoordinateSpanMake(0.01, 0.01)
        let region = MKCoordinateRegion(center: location, span:span)
        GPSMapView.setRegion(region, animated: true)
        GPSMapView.showsUserLocation = true
        
        
        locationList.append(ballTower)
        locationList.append(library)
        locationList.append(studentCenter)
       
         parser()
       
        /*for index in locationList{
           
            let coordinate = CLLocationCoordinate2D(latitude: index.latitude, longitude: index.longitude)
            
            let pin = PinClass(coordinate: coordinate, name: index.locationName, desc: index.locationSubName, trivia: index.trivia)
            
            pinList.append(pin)
            GPSMapView.addAnnotation(pin.makeAnnotation())
        }*/
        
        
        
     
        
       
       
        
        //====================================BACKGROUND================================
        
        backGround.async {
            
            
            if(self.TourType == 1){
                
                self.guidedTourFunction()
                
            }else if(self.TourType == 2){
                
                self.freeRoamTourFunction()
            }else if(self.TourType == 3){
                
                self.randomGuidedTourFunction()
            }
            else{
                print ("error")
            }
            
            
        }
        //====================================BACKGROUND================================
        

        
       
    }
//=====================================VIEW DID LOAD=================================
    
//=====================================UPDATE USER LOCATION=================================
    
    func UpdateUserLocation() {
        
        print("Updated Location")
        
        locationManager.startUpdatingLocation()
        
        GPSMapView.showsUserLocation = true
        
        locationManager.stopUpdatingLocation()
        
        let newLatitude: Float = Float(latestLocation.latitude)
        let newLongitude: Float = Float(latestLocation.longitude)
        
        let location = CLLocationCoordinate2D(latitude: CLLocationDegrees(newLatitude), longitude: CLLocationDegrees(newLongitude))
        let span = MKCoordinateSpanMake(0.01, 0.01)
        let region = MKCoordinateRegion(center: location, span:span)
        GPSMapView.setRegion(region, animated: true)
        GPSMapView.showsUserLocation = true
        
        
    }
//=====================================UPDATE USER LOCATION=================================
    
//=====================================TOURS=================================
    
    //@IBOutlet weak var LocationLabel: UILabel!
    var rangeVariable = 0.0005
    
    func guidedTourFunction(){
        sleep(5)
        
       
       
        var tourNum = 1
        var destination = false
        var destinationLoc = LocationClass()
        
        print(latestLocation.latitude)
        print(latestLocation.longitude)
        
        
        while(!back){
            
            if(!destination){
                
            
                for index in 0...locationList.count - 1{
                  
                    
                    if(locationList[index].guidedTour == tourNum){
                        
                        //print("testing132")
                        
                        destinationLoc = locationList[index]
                        destination = true
                        
                        
                        let coordinate = CLLocationCoordinate2D(latitude: destinationLoc.latitude, longitude: destinationLoc.longitude)
                        
                        let pin = PinClass(coordinate: coordinate, name: destinationLoc.locationName, desc: destinationLoc.locationSubName, trivia: destinationLoc.trivia)
                        
                        pinList.append(pin)
                        DispatchQueue.main.async(execute: {
                            self.tourInfoLabel.text = "head to " + pin.pinName
                            self.GPSMapView.addAnnotation(pin.makeAnnotation())
                        })
    
                        
                    }
                    
                }
            } else{
                
                while(!continues || !(abs(self.latestLocation.latitude - destinationLoc.latitude) <= rangeVariable) || !(abs(self.latestLocation.longitude - destinationLoc.longitude) <= rangeVariable)){
                    
                    if((abs(self.latestLocation.latitude - destinationLoc.latitude) <= rangeVariable) && (abs(self.latestLocation.longitude - destinationLoc.longitude) <= rangeVariable) ){
                    
                   
                        DispatchQueue.main.async(execute: {

                        self.tourInfoLabel.text = "You have reached the " + destinationLoc.locationName + " Click the pin Title for more information"
                        })
                        destination = false
                        //tourNum = tourNum + 1
                        sleep(3)
                   
                        
                    
                    }else{
                        DispatchQueue.main.async(execute: {

                        self.tourInfoLabel.text = "head to " + destinationLoc.locationName
                        })
                    }
                    
                    
                }
                continues = false
                tourNum = tourNum + 1
                DispatchQueue.main.async(execute: {
                    
                    self.performSegue(withIdentifier: "DetailSegue", sender: self)
                })
            }
        }
      
    }
    func freeRoamTourFunction(){
        
        //tourInfoLabel.text = "Free Roam Mode"
        print("free roam works")
        var index = 1
        
            
        for index in 0...locationList.count - 1{
                
            var destinationLoc = locationList[index]
            
            let coordinate = CLLocationCoordinate2D(latitude: destinationLoc.latitude, longitude: destinationLoc.longitude)
            
            let pin = PinClass(coordinate: coordinate, name: destinationLoc.locationName, desc: destinationLoc.locationSubName, trivia: destinationLoc.trivia)
            
            pinList.append(pin)
            DispatchQueue.main.async(execute: {
                //self.LocationLabel.text = "head to " + pin.pinName
                self.GPSMapView.addAnnotation(pin.makeAnnotation())
            })
           
        
        }
 
    
    
    }
    func randomGuidedTourFunction(){
        print("Random Guided works")
        
        sleep(5)
        
        //tourInfoLabel.text = "Random Tour Mode"
        
        var tourNum = 1
        var destination = false
        var destinationLoc = LocationClass()
        
        while(!back){
            
            if(!destination){
                let randomTourNum = Int(arc4random_uniform(9) + 1)
                
                
                for index in 0...locationList.count - 1{
                    
                    
                    if(locationList[index].guidedTour == randomTourNum){
                        
                        //print("testing132")
                        
                        destinationLoc = locationList[index]
                        destination = true
                        
                        
                        let coordinate = CLLocationCoordinate2D(latitude: destinationLoc.latitude, longitude: destinationLoc.longitude)
                        
                        let pin = PinClass(coordinate: coordinate, name: destinationLoc.locationName, desc: destinationLoc.locationSubName, trivia: destinationLoc.trivia)
                        
                        pinList.append(pin)
                        DispatchQueue.main.async(execute: {
                            self.tourInfoLabel.text = "head to " + pin.pinName
                            self.GPSMapView.addAnnotation(pin.makeAnnotation())
                        })
                        
                        
                    }
                    
                }
            }
            else{
                
                while(!continues || !(abs(self.latestLocation.latitude - destinationLoc.latitude) <= rangeVariable) || !(abs(self.latestLocation.longitude - destinationLoc.longitude) <= rangeVariable)){
                    
                    if((abs(self.latestLocation.latitude - destinationLoc.latitude) <= rangeVariable) && (abs(self.latestLocation.longitude - destinationLoc.longitude) <= rangeVariable) ){
                        
                        
                        DispatchQueue.main.async(execute: {
                            
                            self.tourInfoLabel.text = "You have reached the " + destinationLoc.locationName + " Click the pin Title for more information"
                        })
                        destination = false
                        //tourNum = tourNum + 1
                        sleep(3)
                        
                        
                        
                    }else{
                        DispatchQueue.main.async(execute: {
                            
                            self.tourInfoLabel.text = "head to " + destinationLoc.locationName
                        })
                    }
                    
                    
                }
                continues = false
                tourNum = tourNum + 1
                DispatchQueue.main.async(execute: {
                    
                    self.performSegue(withIdentifier: "DetailSegue", sender: self)
                })
            }
        }

            
            
            
            /*else{
                
                if((abs(self.latestLocation.latitude - destinationLoc.latitude) <= rangeVariable) && (abs(self.latestLocation.longitude - destinationLoc.longitude) <= rangeVariable) ){
                    //index += 1
                    DispatchQueue.main.async(execute: {
                        print("-a-fa-dfttes")
                    })
                    //print("teseettt")
                    self.tourInfoLabel.text = "You have reached the " + destinationLoc.locationName
                    destination = false
                    tourNum = tourNum + 1
                    sleep(2)
                    
                    //self.LocationLabel.text = "Head to the Library"
                    
                }
            }
        }*/

        
    }
    
//=====================================TOURS=================================
    
//=====================================MAP VIEW/SEGUE=================================
    

    func locationManager(_ manager: CLLocationManager!, didUpdateLocations locations: [CLLocation]!){
        
        latestLocation = manager.location!.coordinate
        
       
        
    }
    
    
    
    
    func mapView(_ mapView: MKMapView!, viewFor annotation: MKAnnotation!) -> MKAnnotationView!{
        
        let identifier = "BallState Bell Tower"
        var view: MKPinAnnotationView
        if let dequeuedView = mapView.dequeueReusableAnnotationView(withIdentifier: identifier) as? MKPinAnnotationView{
            dequeuedView.annotation = annotation
            view = dequeuedView
        }else{
            view = MKPinAnnotationView(annotation: annotation, reuseIdentifier: identifier)
            view.canShowCallout = true
            view.calloutOffset = CGPoint(x: -5, y: 5)
            let button = (UIButton(type: .detailDisclosure))
            button.isHidden = true
            let buttonView = button as UIView
            view.rightCalloutAccessoryView = buttonView
            
            
        }
        return view
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any!) {
        if (segue.identifier == "DetailSegue") {
             let dest = segue.destination as! DestinationViewController
                dest.Location = selectedLocation
        }

    }
   
    
    func mapView(_ mapView: MKMapView, annotationView view: MKAnnotationView, calloutAccessoryControlTapped control: UIControl){
        if control == view.rightCalloutAccessoryView{
            for index in pinList{
                if(index.makeAnnotation().title == (view.annotation?.title)!){
                   
                        
                    
                    selectedLocation = index
                    
                    
                }
            }
            if(TourType == 2){
                self.performSegue(withIdentifier: "DetailSegue", sender: self)
                
            }
            continues = true
        }
        
         print("---button success---")
    }
    
//=====================================MAP VIEW/SEGUE=================================
    
//====================================PARSER=================================
    
    func parser(){
        
        
        let urlAsStringMain = "https://spreadsheets.google.com/feeds/list/1Q1EE8aULP4ZQaQrvq3IatJAjiPhOPuGTXH7TUdTvor4/od6/public/basic?alt=json"
        
        let urlAsStringImage = "https://spreadsheets.google.com/feeds/list/1Q1EE8aULP4ZQaQrvq3IatJAjiPhOPuGTXH7TUdTvor4/ofcbsq9/public/basic?alt=json"
        
        let urlAsStringTrivia = "https://spreadsheets.google.com/feeds/list/1Q1EE8aULP4ZQaQrvq3IatJAjiPhOPuGTXH7TUdTvor4/ohcrm63/public/basic?alt=json"
        
        
        //print (urlAsString)
        let url = URL(string: urlAsStringMain)
        let urlSession = URLSession.shared
        let task = urlSession.dataTask(with: url!, completionHandler: {data, response, error -> Void in
            print("Task completed")
            print(data)
            
            if (error != nil){
                print(error!.localizedDescription)
                
            }
            do{
                
                if let jsonResult = try JSONSerialization.jsonObject(with: data!, options: JSONSerialization.ReadingOptions.mutableContainers) as? NSDictionary{
                    print("Success")
                    //print(jsonResult["feed"] )
                    
                    let feed = jsonResult["feed"] as? NSDictionary // Json Value of 'feed' which is the RSS in the data.
                    let entry = feed?["entry"] as? NSArray // Json Value of 'entry' which is the RSS in the data.
                    
                    //print(entry)
                    print("====")
                
                    
                   for item in entry!{
                        let dict = item as? NSDictionary
                        var content = dict?["content"] as? NSDictionary
                    
                        let info = content?["$t"] as? String
                    
                        let fullNameArr = info?.components(separatedBy: ", ")
                    
                    var firstLoc =  LocationClass()
                    for thing in fullNameArr! {
                        let itemArr = thing.components(separatedBy: ": ")
                        
                        
                        if( itemArr[0] == "name"){
                            firstLoc.locationName = itemArr[1]
                            
                        } else if( itemArr[0] == "type"){
                            firstLoc.type = itemArr[1]
                            
                        }else if( itemArr[0] == "subname"){
                            firstLoc.locationSubName = itemArr[1]
                            
                        }else if( itemArr[0] == "latitude"){
                            firstLoc.latitude = Double(itemArr[1])!
                            
                        }else if( itemArr[0] == "longitude"){
                            firstLoc.longitude = Double(itemArr[1])!
                            
                        }else if( itemArr[0] == "guidedtour"){
                            firstLoc.guidedTour = Int(itemArr[1])!
                            
                        }
                        
                        //print (itemArr)
                    }
                    self.locationList.append(firstLoc)
                    
                    
                        //print(info)
                        //print(content)
                    
                    
                    
                    
                        
                    }
                    
                   /* for l in jsonResult {
                        let content = l as? NSDictionary
                        let subContent = content?["feed"] as? NSDictionary
                        print(content)
                        
                        var id = result?["StudentId"]!
                        var lName = result?["LastName"]!
                        var fName = result?["FirstName"]!
                        var major = result?["Major"]!
                        var year = result?["Year"]!
                        var gpa = result?["GPA"]!*/
                        
                        
                        
                        
                       /* if var JsonLat = content?["latitude"]{
                            print("did find latitude")
                        }else{
                            print("didnt find latitude")
                        }*/
                        /*let JsonLog = content?["longitude"]
                        let JsonTourNum = content?["guidedtour"]
                        let JsonSubName = content?["subname"]
                        let JsonName = content?["name"]
                        let JsonType = content?["type"]
                        print(JsonLat)
                        print("---")*/
                    
                    //}
                
                }
                
            }
                
            catch{
            print("has Error")}
            
        })
        
        task.resume()
        sleep(2)
       
        
        
    }
//====================================PARSER=================================
    
    func back(sender: UIBarButtonItem){
        
        updateLocationTimer.invalidate()//Timer Stop
        back = true
        
        //backGround.suspend()//-----------------------------------------------------
        
        
        
        _ = navigationController?.popViewController(animated: true)
    }

    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}





//====================================TEMP CODE=================================

/*func locationManager(_ manager: CLLocationManager!, didUpdateLocations locations: [CLLocation]!){
    
    //var latestLocation: CLLocation = locations[locations.count - 1]
    latestLocation = manager.location!.coordinate
    
    
    //latitude_text = String(format: "%.4f", latestLocation.latitude)
    //longitude_text = String(format: "%.4f", latestLocation.longitude)
    
    //print(latitude_text)
    //print(longitude_text)
    
    
    // if startLocation == nil{
    //   startLocation = latestLocation as! CLLocation
    //}
    
    //var distanceBetween: CLLocationDistance = latestLocation.distance( from: startLocation)
    
    //var distance_text = String(format: "%.2f", distanceBetween)
    
}

//func locationManager(_ manager: CLLocationManager, didfailWithError error: NSError){
//  print("eroooroejrelajiejflaj")
//}
 
 
 //let urlAsString = "https://itunes.apple.com/search?term=Metallica&entity="
 //let urlAsString = "https://docs.google.com/spreadsheets/d/1Q1EE8aULP4ZQaQrvq3IatJAjiPhOPuGTXH7TUdTvor4/gviz/tq?tqx=out:json&tq&gid=0"
 
 */

