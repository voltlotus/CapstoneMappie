//
//  LocationClass.swift
//  CapstoneProject(Mappi)
//
//  Created by hayden rusk on 1/19/17.
//  Copyright © 2017 BSUCS320. All rights reserved.
//

import Foundation


class LocationClass {
    
    var locationName = ""
    var latitude = 0.0
    var longitude = 0.0
    var locationSubName = ""
    var trivia = ""
    var type = ""
    var guidedTour = 0
    
    
    
    
    
    
    
    /*init(locationName: String,latitude: Float,longitude: Float, description: String = "", trivia: String = "" ) {
        
        location = locationName
        self.latitude = Double(latitude)
        self.longitude = Double(longitude)
        self.description = description
        self.trivia = trivia
        
        
    }*/
    
    
    
}
