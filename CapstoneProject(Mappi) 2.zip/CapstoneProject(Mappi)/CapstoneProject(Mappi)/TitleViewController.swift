//
//  TitleViewController.swift
//  CapstoneProject(Mappi)
//
//  Created by hayden rusk on 1/30/17.
//  Copyright © 2017 BSUCS320. All rights reserved.
//

import UIKit

class TitleViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    var info = 0
    @IBAction func FreeRoamButton(_ sender: Any) {
        info = 1
        //1 = free roam
        
        self.performSegue(withIdentifier: "TourSegue", sender: self)

        
    }
   

    @IBAction func GuidedTourButton(_ sender: Any) {
        info = 2
        
        self.performSegue(withIdentifier: "TourSegue", sender: self)

        
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any!) {
        if (segue.identifier == "TourSegue") {
            let dest = segue.destination as! ViewController
            dest.TourType = info
        }
     
     }
 
}
