//
//  PinClass.swift
//  CapstoneProject(Mappi)
//
//  Created by hayden rusk on 11/1/16.
//  Copyright © 2016 BSUCS320. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation

class PinClass: NSObject, MKAnnotation {
    var myCoordinate: CLLocationCoordinate2D
    
    //var pinLatitude = 0
    //var pinLongitude = 0
    
    
    var pinName = ""
    var pinDesc = ""
    var annotation = MKPointAnnotation()
    var pinTrivia = ""
    
    
    
    init(coordinate: CLLocationCoordinate2D, name: String, desc: String, trivia: String = "" ){
        
        pinName = name
        pinDesc = desc
        myCoordinate = coordinate
        pinTrivia = trivia
        
        
        
    }
    var coordinate: CLLocationCoordinate2D{
        return myCoordinate
    }
    func makeAnnotation() -> MKPointAnnotation{
        
        annotation.coordinate = coordinate
        annotation.title = pinName
        annotation.subtitle = pinDesc
        
        
        return annotation
        
        
    }
}
