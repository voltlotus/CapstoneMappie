//
//  ViewController.swift
//  CapstoneProject(Mappi)
//
//  Created by hayden rusk on 10/16/16.
//  Copyright © 2016 BSUCS320. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation



class ViewController: UIViewController, MKMapViewDelegate, CLLocationManagerDelegate {
    var TourType = 0
    
    var backGround = DispatchQueue(label: "com.app.queue", qos: .background,target: nil)
    
    func UpdateUserLocation() {
    
        print("Updated Location")
        
        locationManager.startUpdatingLocation()
        
        GPSMapView.showsUserLocation = true
        
        locationManager.stopUpdatingLocation()
        
        let newLatitude: Float = Float(latestLocation.latitude)
        let newLongitude: Float = Float(latestLocation.longitude)
             
        let location = CLLocationCoordinate2D(latitude: CLLocationDegrees(newLatitude), longitude: CLLocationDegrees(newLongitude))
        let span = MKCoordinateSpanMake(0.01, 0.01)
        let region = MKCoordinateRegion(center: location, span:span)
        GPSMapView.setRegion(region, animated: true)
        GPSMapView.showsUserLocation = true
        
        
    }
   
    @IBOutlet weak var GPSMapView: MKMapView!
    
    var locationManager: CLLocationManager = CLLocationManager()
    var startLocation: CLLocation!
    
    var longitude_text = ""
    var latitude_text = ""
    
    
    var userLatitude = 40.20370
    var userLongitude = -85.40797
    
    //var bellTowerLat = 40.20370
    //var bellTowerLong = -85.40797
 
 
    let bellTowerAnnotation = MKPointAnnotation()
    
    //var latitudeList: [Double] = [40.20370, 40.20320]
    //var longitudeList: [Double] = [-85.40797, -85.40647]
    
    let ballTower = LocationClass(locationName: "Ball Tower", latitude: 40.20370, longitude: -85.40797, description: "BSU", trivia: "idk bells and stuff")
    let library = LocationClass(locationName: "Bracken Library", latitude: 40.203200, longitude: -85.40647,description: "BSU",trivia: "where this app was made woooooo")
    
    var locationList: [LocationClass] = []
    
    
    
    //var descList: [String] = ["BSU", "BSU"]
    //var nameList: [String] = ["Ball Tower", "Bracken Library"]
    
    var pinList: [PinClass] = []
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        UpdateUserLocation()
        
         // comment out the timer
        //var updateTimer = Timer.scheduledTimer(timeInterval: 15.0, target: self, selector: "UpdateUserLocation", userInfo: nil, repeats: true)
    
        Timer.scheduledTimer(timeInterval: 15.0, target: self, selector: #selector(ViewController.UpdateUserLocation), userInfo: nil, repeats: true)
        
        
        self.GPSMapView.delegate = self
        
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.delegate = self
        locationManager.requestWhenInUseAuthorization()
        locationManager.startUpdatingLocation()
        //startLocation = nil
        
        
        let location = CLLocationCoordinate2D(latitude: userLatitude, longitude: userLongitude)
        let span = MKCoordinateSpanMake(0.01, 0.01)
        let region = MKCoordinateRegion(center: location, span:span)
        GPSMapView.setRegion(region, animated: true)
        GPSMapView.showsUserLocation = true
        
        
        locationList.append(ballTower)
        locationList.append(library)
        
       
        for index in locationList{
           
            let coordinate = CLLocationCoordinate2D(latitude: index.latitude, longitude: index.longitude)
            
            let pin = PinClass(coordinate: coordinate, name: index.location, desc: index.description, trivia: index.trivia)
            
            pinList.append(pin)
            GPSMapView.addAnnotation(pin.makeAnnotation())
        }
        
        
        
        self.navigationItem.hidesBackButton = true
        let newBackButton = UIBarButtonItem(title: "Back", style: UIBarButtonItemStyle.plain, target: self, action: #selector(ViewController.back(sender:)))
        self.navigationItem.leftBarButtonItem = newBackButton
        
        //=========================================
        
        
        
        
        backGround.async {
            
            
            if(self.TourType == 1){
                
                self.guidedTourFunction()
                
            }else if(self.TourType == 2){
                
                self.freeRoamTourFunction()
            }
            else{
                print ("error")
            }
            
            
        }
        

        
       
    }
    
    
    @IBOutlet weak var LocationLabel: UILabel!
    var rangeVariable = 0.0001
    
    func guidedTourFunction(){
        
        LocationLabel.text = "Guided Tour Mode"
        print("----")
        print(self.locationList.count)
        print(self.latestLocation.latitude)
        print("- -")
        print("guided works")
        var index = 1
        
        
        
        while(index <= self.locationList.count){
            
            
            if((self.latestLocation.latitude - self.ballTower.latitude <= rangeVariable) && (self.latestLocation.longitude - self.ballTower.longitude <= rangeVariable) ){
                index += 1
                
                self.LocationLabel.text = "You have reached the BellTower"
                sleep(10)
                self.LocationLabel.text = "Head to the Library"
                
            }else if((self.latestLocation.latitude - self.library.latitude <= rangeVariable) && (self.latestLocation.longitude - self.library.longitude <= rangeVariable)){
                index += 1
                
                self.LocationLabel.text = "You have reached the Library"
                sleep(10)
                self.LocationLabel.text = "Head to the Student Center"
            }/*else if((self.latestLocation.latitude - self.studentCent.latitude <= rangeVariable) && (self.latestLocation.longitude - self.studentCent.longitude <= rangeVariable)){
                index += 1
                
                self.LocationLabel.text = "You have reached the Student Center"
                sleep(10)
                self.LocationLabel.text = "You have finished the Tour!"
            }*/
        }
        
        
        
    }
    func freeRoamTourFunction(){
        
        LocationLabel.text = "Free Roam Mode"
        print("free roam works")
        var index = 1
        
        while(index <= self.locationList.count){
            
            
            if((latestLocation.latitude - ballTower.latitude <= rangeVariable) && (latestLocation.longitude - ballTower.longitude <= rangeVariable) ){
                index += 1
                
                self.LocationLabel.text = "You have reached the BellTower"
                
                
            }else if((latestLocation.latitude - library.latitude <= rangeVariable) && (latestLocation.longitude - library.longitude <= rangeVariable)){
                index += 1
                
                self.LocationLabel.text = "You have reached the Library"
                
            }
        
        }
    
    
    }
    var latestLocation: CLLocationCoordinate2D = CLLocationCoordinate2D()

    func locationManager(_ manager: CLLocationManager!, didUpdateLocations locations: [CLLocation]!){
        
        //var latestLocation: CLLocation = locations[locations.count - 1]
        latestLocation = manager.location!.coordinate
        
        
        //latitude_text = String(format: "%.4f", latestLocation.latitude)
        //longitude_text = String(format: "%.4f", latestLocation.longitude)
        
        //print(latitude_text)
        //print(longitude_text)
        
        
       // if startLocation == nil{
        //   startLocation = latestLocation as! CLLocation
        //}
        
        //var distanceBetween: CLLocationDistance = latestLocation.distance( from: startLocation)
        
        //var distance_text = String(format: "%.2f", distanceBetween)
        
    }
    
    //func locationManager(_ manager: CLLocationManager, didfailWithError error: NSError){
      //  print("eroooroejrelajiejflaj")
    //}
    
    
    func mapView(_ mapView: MKMapView!, viewFor annotation: MKAnnotation!) -> MKAnnotationView!{
        
        let identifier = "BallState Bell Tower"
        var view: MKPinAnnotationView
        if let dequeuedView = mapView.dequeueReusableAnnotationView(withIdentifier: identifier) as? MKPinAnnotationView{
            dequeuedView.annotation = annotation
            view = dequeuedView
        }else{
            view = MKPinAnnotationView(annotation: annotation, reuseIdentifier: identifier)
            view.canShowCallout = true
            view.calloutOffset = CGPoint(x: -5, y: 5)
            let button = (UIButton(type: .detailDisclosure))
            button.isHidden = true
            let buttonView = button as UIView
            view.rightCalloutAccessoryView = buttonView
            
            
        }
        return view
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any!) {
        if (segue.identifier == "BellTowerSegue") {
             let dest = segue.destination as! DestinationViewController
                dest.Location = selectedLocation
        }

    }
    var selectedLocation: PinClass!
    
    func mapView(_ mapView: MKMapView, annotationView view: MKAnnotationView, calloutAccessoryControlTapped control: UIControl){
        if control == view.rightCalloutAccessoryView{
            for index in pinList{
                if(index.makeAnnotation().title == (view.annotation?.title)!){
                    selectedLocation = index
                }
            }
            
            self.performSegue(withIdentifier: "BellTowerSegue", sender: self)
            
        }
        
         print("---button success---")
    }
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    
    func parser(){
        
        //let urlAsString = "https://itunes.apple.com/search?term=\(search)&entity=\(entityTxt)"
        let urlAsString = "https://docs.google.com/spreadsheets/d/1Q1EE8aULP4ZQaQrvq3IatJAjiPhOPuGTXH7TUdTvor4/gviz/tq?tqx=out:json&tq&gid=0"
        print (urlAsString)
        let url = URL(string: urlAsString)
        let urlSession = URLSession.shared
        let task = urlSession.dataTask(with: url!, completionHandler: {data, response, error -> Void in
            print("Task completed")
            
            if (error != nil){
                print(error!.localizedDescription)
                
            }
            do{
                if let jsonResult = try JSONSerialization.jsonObject(with: data!, options: JSONSerialization.ReadingOptions.mutableContainers) as? NSDictionary{
                    
                    
                    
                }
            }
                
            catch{}
            
        })
        
        task.resume()
        sleep(2)
        //self.infoTabelView.reloadData()
        
        
    }
    
    func back(sender: UIBarButtonItem){
        backGround.suspend()//-----------------------------------------------------
        _ = navigationController?.popViewController(animated: true)
    }



}

