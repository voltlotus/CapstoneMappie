//
//  DestinationViewController.swift
//  CapstoneProject(Mappi)
//
//  Created by hayden rusk on 1/19/17.
//  Copyright © 2017 BSUCS320. All rights reserved.
//

import UIKit

class DestinationViewController: UIViewController {
    
    @IBOutlet weak var LongitudeValue: UILabel!
    @IBOutlet weak var LatitudeValue: UILabel!
    @IBOutlet weak var locationName: UILabel!
    @IBOutlet weak var DescritptionName: UILabel!
    @IBOutlet weak var TriviaInformation: UITextView!
    @IBOutlet weak var ImageNameLabel: UILabel!
    @IBOutlet weak var ImageDescLabel: UILabel!
    @IBOutlet weak var LocationImage: UIImageView!
    
    var Location: PinClass!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        print(Location.pinName + "---")
        
        locationName.text = Location.pinName
        DescritptionName.text = Location.pinDesc
        LatitudeValue.text = String(Location.myCoordinate.latitude)
        LongitudeValue.text = String(Location.myCoordinate.longitude)
        TriviaInformation.text = (Location.pinTrivia).joined(separator: ", ")
        if !(Location.pinImage).isEmpty{
            ImageNameLabel.text = Location.pinImage.joined()
        }
        
        if let url = URL(string: Location.pinImage[0]){
            URLSession.shared.dataTask(with: url){ (data, response, error) in
                DispatchQueue.main.async {
                    self.LocationImage.image = UIImage(data: data!)
                }
           
            
            }.resume()
        }
        
        
        
        
      
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source


}
