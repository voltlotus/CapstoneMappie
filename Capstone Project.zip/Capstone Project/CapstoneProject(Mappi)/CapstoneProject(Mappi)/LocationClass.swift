//
//  LocationClass.swift
//  CapstoneProject(Mappi)
//
//  Created by hayden rusk on 1/19/17.
//  Copyright © 2017 BSUCS320. All rights reserved.
//

import Foundation


class LocationClass {
    
    var locationName = ""
    var latitude = 0.0
    var longitude = 0.0
    var locationSubName = ""
    var type = [String]()
    var guidedTour = 0
    var imageName = [String]()
    var imageDesc = [String]()
    var imageHyper = [String]()
    var trivia = [String]()
    var rangeVariable = Double()
    
}
