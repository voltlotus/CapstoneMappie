//
//  TitleViewController.swift
//  CapstoneProject(Mappi)
//
//  Created by hayden rusk on 2/6/17.
//  Copyright © 2017 BSUCS320. All rights reserved.
//

import UIKit

class TitleViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        //self.view.backgroundColor = UIColor(patternImage: UIImage(named: "CapstoneFrontPage.png")!)
        // Do any additional setup after loading the view.
    }
   
    @IBAction func InfoButton(_ sender: Any) {
        
        
    }
    
    var info = 0
    @IBAction func GuidedTourButton(_ sender: Any) {
        info = 1
        
        
        self.performSegue(withIdentifier: "TourSegue", sender: self)
        
    }
    @IBAction func FreeRoamButton(_ sender: Any) {
        info = 2
        
        
        self.performSegue(withIdentifier: "TourSegue", sender: self)
        
    }
    
    @IBAction func RandomTourButton(_ sender: Any) {
        info = 3
       
        
        self.performSegue(withIdentifier: "TourSegue", sender: self)
        
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any!) {
        if (segue.identifier == "TourSegue") {
            let dest = segue.destination as! ViewController
            dest.TourType = info
        }
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
   
    

   

}
