//
//  ViewController.swift
//  CapstoneProject(Mappi)
//
//  Created by hayden rusk on 10/16/16.
//  Copyright © 2016 BSUCS320. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation



class ViewController: UIViewController, MKMapViewDelegate, CLLocationManagerDelegate {
    
//=====================================VARIABLES=================================
    var latestLocation: CLLocationCoordinate2D = CLLocationCoordinate2D()
    
    
    var selectedLocation: PinClass!
    
    @IBOutlet weak var tourInfoLabel: UITextView!
    
    var continues = false // Have not clicked to go to the detailed view controller yet
    var back = false // this is whether the back button was pushed or not (stops tours)
    
    var destPin = PinClass()
    
    var TourType = 0
    //var backGround = DispatchQueue(label: "com.app.queue", qos: .background,target: nil)
    
    @IBOutlet weak var GPSMapView: MKMapView!
    
    var locationManager: CLLocationManager = CLLocationManager()
    var startLocation: CLLocation!
    
    var longitude_text = ""
    var latitude_text = ""
    
    var userLatitude = 40.20370
    var userLongitude = -85.40797
    
    var locationList: [LocationClass] = []
    
    var pinList: [PinClass] = []
    
    var updateLocationTimer: Timer = Timer()
    
    var destinationLoc = LocationClass()
    
    var rangeVariable = 0.0005
    
    var tourNum = 1
    
//=====================================VARIABLES=================================
    
//=====================================VIEW DID LOAD=================================
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationItem.hidesBackButton = true
        let newBackButton = UIBarButtonItem( title: "Back", style: UIBarButtonItemStyle.plain, target: self, action: #selector(ViewController.back(sender: )))
        self.navigationItem.leftBarButtonItem = newBackButton
        
        
        //UpdateUserLocation()
        
        self.GPSMapView.delegate = self
        
       

        
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.delegate = self
        locationManager.requestWhenInUseAuthorization()
        //locationManager.startUpdatingLocation()
        //sleep(1)
        //GPSMapView.showsUserLocation = true
        //locationManager.stopUpdatingLocation()
        
        //startLocation = nil
        
        
        let location = CLLocationCoordinate2D(latitude: userLatitude, longitude: userLongitude)
        let span = MKCoordinateSpanMake(0.01, 0.01)
        let region = MKCoordinateRegion(center: location, span:span)
        GPSMapView.setRegion(region, animated: false)
        //GPSMapView.centerCoordinate = location
        GPSMapView.showsUserLocation = true
        locationManager.stopUpdatingLocation()
        
        
        parser()
        

       
            
            
            if(TourType == 1){
                
                guidedTourFunction()
                
            }else if(TourType == 2){
                
                freeRoamTourFunction()
            }else if(TourType == 3){
                
                randomGuidedTourFunction()
            }
            else{
                print ("error")
            }
            
            checkAtLocation()
        
        //====================================TIMER================================
        updateLocationTimer = Timer.scheduledTimer(timeInterval: 5.0, target: self, selector: #selector(ViewController.checkAtLocation), userInfo: nil, repeats: true)
        //====================================TIMER================================
        
       
    }
//=====================================VIEW DID LOAD=================================
    
    
    func checkAtLocation(){
        //UpdateUserLocation()
        locationManager.startUpdatingLocation()
        //sleep(1)
        //print(latestLocation.latitude)
        if(TourType == 2){
            for pin in pinList {
                if((abs(latestLocation.latitude - pin.coordinate.latitude) <= rangeVariable) && (abs(latestLocation.longitude - pin.coordinate.longitude) <= rangeVariable) ){
                    pin.atLocation = true
                    
                    
                }else{
                    pin.atLocation = false
                }
            }
        
        }else{
            
            if((abs(latestLocation.latitude - destinationLoc.latitude) <= rangeVariable) && (abs(latestLocation.longitude - destinationLoc.longitude) <= rangeVariable) ){
                pinList[pinList.count-1].atLocation = true
            
            }else{
                pinList[pinList.count-1].atLocation = false
            }
            
        }
        //locationManager.stopUpdatingLocation()
    }
    
//=====================================UPDATE USER LOCATION=================================
    
    
    
    func UpdateUserLocation() {
        
        print("Updated Location")
        
        locationManager.startUpdatingLocation()
        sleep(1)
        
        GPSMapView.showsUserLocation = true
        
        locationManager.stopUpdatingLocation()
        
        let newLatitude: Float = Float(latestLocation.latitude)
        let newLongitude: Float = Float(latestLocation.longitude)
        
        /*let location = CLLocationCoordinate2D(latitude: CLLocationDegrees(newLatitude), longitude: CLLocationDegrees(newLongitude))
        let span = MKCoordinateSpanMake(0.01, 0.01)
        let region = MKCoordinateRegion(center: location, span:span)
        GPSMapView.setRegion(region, animated: true)
        GPSMapView.showsUserLocation = true
        */print(newLatitude)
        print(newLongitude)
        
        
    }
//=====================================UPDATE USER LOCATION=================================
    
//=====================================TOURS=================================
    
    
    
    func guidedTourFunction(){
        sleep(2)
        
       
       
        //var tourNum = 1
        //var destination = false
        //var destinationLoc = LocationClass()
        
        
        //while(!back){
            
            if(tourNum <= maxTourNum){
            
                for index in 0...locationList.count - 1{
                  
                    
                    if(locationList[index].guidedTour == tourNum){

                        
                        destinationLoc = locationList[index]
                        //destination = true
                        
                        
                        let coordinate = CLLocationCoordinate2D(latitude: destinationLoc.latitude, longitude: destinationLoc.longitude)
                        
                        let pin = PinClass(coordinate: coordinate, name: destinationLoc.locationName, desc: destinationLoc.locationSubName, trivia: destinationLoc.trivia, image: destinationLoc.imageHyper)
                        
                        pinList.append(pin)
                        
                        self.tourInfoLabel.text = "Head to " + pin.pinName
                        self.GPSMapView.addAnnotation(pin.makeAnnotation())
                        
    
                        
                    }
                    
                }
            } else{
                // Segue to "WIN" view
        }
        
        
        /*else{
                
                while(!continues || !(abs(self.latestLocation.latitude - destinationLoc.latitude) <= rangeVariable) || !(abs(self.latestLocation.longitude - destinationLoc.longitude) <= rangeVariable)){
                    
                    if((abs(self.latestLocation.latitude - destinationLoc.latitude) <= rangeVariable) && (abs(self.latestLocation.longitude - destinationLoc.longitude) <= rangeVariable) ){
                    
                   
                        DispatchQueue.main.async(execute: {

                        self.tourInfoLabel.text = "You have reached the " + destinationLoc.locationName + " Click the pin Title for more information"
                        })
                        destination = false
                        sleep(2)
                   
                        
                    
                    }else{
                        DispatchQueue.main.async(execute: {

                        self.tourInfoLabel.text = "head to " + destinationLoc.locationName
                        })
                    }
                    
                    
                }
                //Timer.invalidate()
                
                DispatchQueue.main.async(execute: {
                    
                    self.performSegue(withIdentifier: "DetailSegue", sender: self)
                })
                continues = false
                tourNum = tourNum + 1
               
            }*/
        //}*/
      
    }
    func freeRoamTourFunction(){
        
        //var index = 1
        for index in 0...locationList.count - 1{
                
            var destinationLoc = locationList[index]
            
            let coordinate = CLLocationCoordinate2D(latitude: destinationLoc.latitude, longitude: destinationLoc.longitude)
            
            let pin = PinClass(coordinate: coordinate, name: destinationLoc.locationName, desc: destinationLoc.locationSubName, trivia: destinationLoc.trivia, image: destinationLoc.imageHyper)
            
            pinList.append(pin)
            
            self.GPSMapView.addAnnotation(pin.makeAnnotation())
            self.tourInfoLabel.text = "Head to Any Location"
            
           
        
        }
 
    
    
    }
    
    var randomDestination = [Int]()
    func randomGuidedTourFunction(){
        sleep(2)
        
        // var tourNum = 1
        //var destination = false
        //var destinationLoc = LocationClass()
        
       // while(!back){
            
        if(tourNum <= maxTourNum){
        var randomTourNum = Int(arc4random_uniform(UInt32(maxTourNum)) + 1)
        if(!randomDestination.isEmpty){
            
            while(randomDestination.contains(randomTourNum)){
                randomTourNum = Int(arc4random_uniform(UInt32(maxTourNum)) + 1)
            }
            
        }
        randomDestination.append(randomTourNum)
        
                
                
                for index in 0...locationList.count - 1{
                    
                    
                    if(locationList[index].guidedTour == randomTourNum){
                        
                        
                        destinationLoc = locationList[index]
                        //destination = true
                        
                        
                        let coordinate = CLLocationCoordinate2D(latitude: destinationLoc.latitude, longitude: destinationLoc.longitude)
                        
                        let pin = PinClass(coordinate: coordinate, name: destinationLoc.locationName, desc: destinationLoc.locationSubName, trivia: destinationLoc.trivia, image: destinationLoc.imageHyper)
                        
                        pinList.append(pin)
                        
                        self.tourInfoLabel.text = "Head to " + pin.pinName
                        self.GPSMapView.addAnnotation(pin.makeAnnotation())
                        
                        
                        
                    }
                    
             //   }
            //}
            /*else{
                
                while(!continues || !(abs(self.latestLocation.latitude - destinationLoc.latitude) <= rangeVariable) || !(abs(self.latestLocation.longitude - destinationLoc.longitude) <= rangeVariable)){
                    
                    if((abs(self.latestLocation.latitude - destinationLoc.latitude) <= rangeVariable) && (abs(self.latestLocation.longitude - destinationLoc.longitude) <= rangeVariable) ){
                        
                        
                        DispatchQueue.main.async(execute: {
                            
                            self.tourInfoLabel.text = "You have reached the " + destinationLoc.locationName + " Click the pin Title for more information"
                        })
                        destination = false
                        sleep(3)
                        
                        
                        
                    }else{
                        DispatchQueue.main.async(execute: {
                            
                            self.tourInfoLabel.text = "head to " + destinationLoc.locationName
                        })
                    }
                    
                    
                }
                continues = false
                tourNum = tourNum + 1
                DispatchQueue.main.async(execute: {
                    
                    self.performSegue(withIdentifier: "DetailSegue", sender: self)
                })
            }*/
        }
            
        } else {
            // Segue to "WIN" view
        }

        
            
        

        
    }
    
//=====================================TOURS=================================
    
//=====================================MAP VIEW/SEGUE=================================
    

    func locationManager(_ manager: CLLocationManager!, didUpdateLocations locations: [CLLocation]!){
        
        latestLocation = manager.location!.coordinate
        //print(latestLocation.latitude)
        let location = CLLocationCoordinate2D(latitude: CLLocationDegrees(latestLocation.latitude), longitude: CLLocationDegrees(latestLocation.longitude))
        let span = MKCoordinateSpanMake(0.01, 0.01)
        let region = MKCoordinateRegion(center: location, span:span)
        GPSMapView.setRegion(region, animated: true)
        GPSMapView.showsUserLocation = true
        locationManager.stopUpdatingLocation()
        
       
        
    }
    
    
    
    
    func mapView(_ mapView: MKMapView!, viewFor annotation: MKAnnotation!) -> MKAnnotationView!{
        
        let identifier = "BallState Bell Tower"
        var view: MKPinAnnotationView
        if let dequeuedView = mapView.dequeueReusableAnnotationView(withIdentifier: identifier) as? MKPinAnnotationView{
            dequeuedView.annotation = annotation
            view = dequeuedView
        }else{
            view = MKPinAnnotationView(annotation: annotation, reuseIdentifier: identifier)
            view.canShowCallout = true
            view.calloutOffset = CGPoint(x: -5, y: 5)
            let button = (UIButton(type: .detailDisclosure))
            button.isHidden = true
            let buttonView = button as UIView
            view.rightCalloutAccessoryView = buttonView
            
            
        }
        return view
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any!) {
        if (segue.identifier == "DetailSegue") {
             let dest = segue.destination as! DestinationViewController
                dest.Location = selectedLocation
                dest.endTour = endTour
        }

    }
   
    var endTour = false
    func mapView(_ mapView: MKMapView, annotationView view: MKAnnotationView, calloutAccessoryControlTapped control: UIControl){
        if control == view.rightCalloutAccessoryView{
            
            
            for pin in pinList {
                if(pin.pinName == (view.annotation?.title)! && pin.atLocation == true){
                    
                    if(TourType == 1){
                        tourNum = tourNum + 1
                        pinList.popLast()
                        mapView.removeAnnotation(view.annotation!)
                        if(tourNum > maxTourNum){
                            endTour = true
                            updateLocationTimer.invalidate()
                        } else{
                            guidedTourFunction()
                        }
                    }else if(TourType == 3){
                        tourNum = tourNum + 1
                        pinList.popLast()
                        mapView.removeAnnotation(view.annotation!)
                        if(tourNum > maxTourNum){
                            endTour = true
                            updateLocationTimer.invalidate()
                        }
                        randomGuidedTourFunction()

                    }/*else if(TourType == 2){
                        pin.identifier = "visited"//not woooooooooooorking
 
                        let pinView = mapView.dequeueReusableAnnotationView(withIdentifier:"visited") as? MKPinAnnotationView
                        pinView?.pinTintColor = UIColor.gray
                        
                        
                        
                    }*/
                    selectedLocation = pin
                    
                    self.performSegue(withIdentifier: "DetailSegue", sender: self)
                    
                    }
            }
           
        }
        
         print("---button success---")
    }
    
//=====================================MAP VIEW/SEGUE=================================
    
//====================================PARSER=================================
    var maxTourNum = 0
    func parser(){
        
        
        let urlAsStringMain = "https://spreadsheets.google.com/feeds/list/1Q1EE8aULP4ZQaQrvq3IatJAjiPhOPuGTXH7TUdTvor4/od6/public/basic?alt=json"
        
        //let urlAsStringImage = "https://spreadsheets.google.com/feeds/list/1Q1EE8aULP4ZQaQrvq3IatJAjiPhOPuGTXH7TUdTvor4/ofcbsq9/public/basic?alt=json"
        
        //let urlAsStringTrivia = "https://spreadsheets.google.com/feeds/list/1Q1EE8aULP4ZQaQrvq3IatJAjiPhOPuGTXH7TUdTvor4/ohcrm63/public/basic?alt=json"
        
        
        let url = URL(string: urlAsStringMain)
        let urlSession = URLSession.shared
        let task = urlSession.dataTask(with: url!, completionHandler: {data, response, error -> Void in
            print("Task completed")
            
            if (error != nil){
                print(error!.localizedDescription)
                
            }
            do{
                
                if let jsonResult = try JSONSerialization.jsonObject(with: data!, options: JSONSerialization.ReadingOptions.mutableContainers) as? NSDictionary{
                    print("Success")
                    
                    let feed = jsonResult["feed"] as? NSDictionary // Json Value of 'feed' which is the RSS in the data.
                    let entry = feed?["entry"] as? NSArray // Json Value of 'entry' which is the RSS in the data.
                    
                    
                   for item in entry!{
                        let dict = item as? NSDictionary
                        var content = dict?["content"] as? NSDictionary
                    
                        let info = content?["$t"] as? String
                    
                        let fullNameArr = info?.components(separatedBy: ", ")
                    
                    
                    var firstLoc =  LocationClass()
                    for thing in fullNameArr! {
                        let itemArr = thing.components(separatedBy: ": ")
                        
                        
                        if( itemArr[0] == "name"){
                            firstLoc.locationName = itemArr[1]
                            
                        } else if( itemArr[0] == "type"){
                            
                            if itemArr[1].range(of: "; ") != nil{
                                let types = (itemArr[1]).components(separatedBy: "; ")
                                firstLoc.type = types
                                
                            }else{

                                firstLoc.type = [itemArr[1]]
                            }
                            
                        }else if( itemArr[0] == "subname"){
                            firstLoc.locationSubName = itemArr[1]
                            
                        }else if( itemArr[0] == "latitude"){
                            firstLoc.latitude = Double(itemArr[1])!
                            
                        }else if( itemArr[0] == "longitude"){
                            firstLoc.longitude = Double(itemArr[1])!
                            
                        }else if( itemArr[0] == "guidedtour"){
                            firstLoc.guidedTour = Int(itemArr[1])!
                            if(firstLoc.guidedTour > self.maxTourNum){
                                self.maxTourNum = firstLoc.guidedTour
                            }
                            
                        }else if( itemArr[0] == "imagenames"){
                            
                            if itemArr[1].range(of: "; ") != nil{
                                let imageName = (itemArr[1]).components(separatedBy: "; ")
                                firstLoc.imageName = imageName
                                
                            }else{
                                
                                firstLoc.imageName = [itemArr[1]]
                            }
                            
                        }else if( itemArr[0] == "imagedescriptions"){
                            
                            if itemArr[1].range(of: "; ") != nil{
                                let imageDesc = (itemArr[1]).components(separatedBy: "; ")
                                firstLoc.imageDesc = imageDesc
                                
                            }else{
                                
                                firstLoc.imageDesc = [itemArr[1]]
                            }
                            
                        }else if( itemArr[0] == "imagehyperlinks"){
                            //print(itemArr[1])
                            
                            if itemArr[1].range(of: "; ") != nil{
                                let imageHyper = (itemArr[1]).components(separatedBy: "; ")
                                firstLoc.imageHyper = imageHyper
                                print("--4")
                                
                            }else{
                                
                                firstLoc.imageHyper = [itemArr[1]]
                            }
                            
                        }else if( itemArr[0] == "trivia"){
                            
                            
                            if itemArr[1].range(of: "; ") != nil{
                                let trivia = (itemArr[1]).components(separatedBy: "; ")
                                firstLoc.trivia = trivia
                                
                                
                            }else{
                                
                                firstLoc.trivia = [itemArr[1]]
                            }
                            
                        }
                        
                        
                    }
                    self.locationList.append(firstLoc)
  
                    }
                    
                 
                
                }
                
            }
                
            catch{
            print("has Error")}
            
        })
        
        task.resume()
        sleep(2)
       
        
        
    }
//====================================PARSER=================================
    
    func back(sender: UIBarButtonItem){
        
        updateLocationTimer.invalidate()//Timer Stop
        back = true
         
        
        
        _ = navigationController?.popViewController(animated: true)
    }

    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}



