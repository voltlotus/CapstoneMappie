//
//  ViewController.swift
//  CapstoneProject(Mappi)
//
//  Created by hayden rusk on 10/16/16.
//  Copyright © 2016 BSUCS320. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation


class ViewController: UIViewController {

    @IBOutlet weak var GPSMapView: MKMapView!
    
    var userLatitude = 40.2011
    var userLongitude = -85.4070
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        
        let location = CLLocationCoordinate2D(latitude: userLatitude, longitude: userLongitude)
        let span = MKCoordinateSpanMake(0.01, 0.01)
        let region = MKCoordinateRegion(center: location, span:span)
        GPSMapView.setRegion(region, animated: true)
        
        let bellTowerLocation = CLLocationCoordinate2D(latitude: 40.20370, longitude: -85.40797)
        
        var bellTowerAnnotation = MKPointAnnotation()
        
        bellTowerAnnotation.coordinate = bellTowerLocation
        
        
        bellTowerAnnotation.title = "BallState Bell Tower"
        
        GPSMapView.addAnnotation(bellTowerAnnotation)
        
        
        
        
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

