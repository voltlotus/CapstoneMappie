//
//  PinClass.swift
//  CapstoneProject(Mappi)
//
//  Created by hayden rusk on 11/1/16.
//  Copyright © 2016 BSUCS320. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation

class PinClass: NSObject, MKAnnotation {
    var myCoordinate: CLLocationCoordinate2D

    var identifier = "location"
    var pinName = ""
    var pinDesc = ""
    var annotation = MKPointAnnotation()
    var pinTrivia = [String]()
    var pinImage = [String]()
    var atLocation = false
    var atRange = Double(0.0)

    init(coordinate: CLLocationCoordinate2D = CLLocationCoordinate2D(), name: String = "", desc: String = "", trivia: [String] = [String](), image: [String] = [String](), range: Double = Double()){

        pinName = name
        pinDesc = desc
        myCoordinate = coordinate
        pinTrivia = trivia
        pinImage = image
        atRange = range
  
    }
    var coordinate: CLLocationCoordinate2D{
        
        return myCoordinate
    }
    func makeAnnotation() -> MKPointAnnotation{
        
        annotation.coordinate = coordinate
        annotation.title = pinName
        annotation.subtitle = pinDesc
        return annotation
 
    }
}
