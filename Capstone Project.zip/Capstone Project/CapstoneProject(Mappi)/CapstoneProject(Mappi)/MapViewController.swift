//
//  ViewController.swift
//  CapstoneProject(Mappi)
//
//  Created by hayden rusk on 10/16/16.
//  Copyright © 2016 BSUCS320. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation

class MapViewController: UIViewController, MKMapViewDelegate, CLLocationManagerDelegate {
    
    //=====================================VARIABLES=================================
    @IBOutlet weak var tourTextView: UITextView!
    @IBOutlet weak var GPSMapView: MKMapView!
    
    var latestLocation: CLLocationCoordinate2D = CLLocationCoordinate2D()
    var locationManager: CLLocationManager = CLLocationManager()
    var startLocation: CLLocation!
    
    var selectedLocation: PinClass!
    var pinList: [PinClass] = []
    
    var back = false // this is whether the back button was pushed or not (stops tours)
    
    var TourType = 0
    
    var IUPUILatitude = 39.781421
    var IUPUILongitude = -86.165010
    
    var locationList: [LocationClass] = []
    
    var updateLocationTimer: Timer = Timer()
    
    var destinationLoc = LocationClass()
    
    var rangeVariable = 0.0005 ///get rid of soon
    
    var tourNum = 1
    var maxTourNum = 0
    
    var randomDestination = [Int]()
    
    var endTour = false
    
    
    
    //let screenSize = UIScreen.main.bounds
    
    
    //=====================================VARIABLES=================================
    
    //=====================================VIEW DID LOAD=================================
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationItem.hidesBackButton = true
        let newBackButton = UIBarButtonItem( title: "End Tour", style: UIBarButtonItemStyle.plain, target: self, action: #selector(MapViewController.back(sender: )))
        self.navigationItem.leftBarButtonItem = newBackButton
        
        self.GPSMapView.delegate = self
        
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.delegate = self
        locationManager.requestWhenInUseAuthorization()
        
        let location = CLLocationCoordinate2D(latitude: IUPUILatitude, longitude: IUPUILongitude)
        let span = MKCoordinateSpanMake(0.01, 0.01)
        let region = MKCoordinateRegion(center: location, span:span)
        GPSMapView.setRegion(region, animated: false)
        GPSMapView.showsUserLocation = true
        locationManager.stopUpdatingLocation()
        
        parser()
        
        if(TourType == 1){
            
            guidedTourFunction()
            
        }else if(TourType == 2){
            
            freeRoamTourFunction()
        }else if(TourType == 3){
            
            randomGuidedTourFunction()
        }
        else{
            print ("error")
        }
        
        checkAtLocation()
        
        //====================================TIMER================================
        updateLocationTimer = Timer.scheduledTimer(timeInterval: 5.0, target: self, selector: #selector(MapViewController.checkAtLocation), userInfo: nil, repeats: true)
        //====================================TIMER================================
        
    }
    //=====================================VIEW DID LOAD=================================
    
    func checkAtLocation(){
        
        locationManager.startUpdatingLocation()
        
        if(TourType == 2){
            for pin in pinList {
                let rangeLat: Double = abs(Double( pin.atRange / 69.172)) // changing the feet -> miles -> degrees for the rangeVariable
                let rangeLon: Double = abs(Double(pin.atRange / 69.172)/(cos(pin.coordinate.latitude)))
                if((abs(latestLocation.latitude - pin.coordinate.latitude) <= rangeLat) && (abs(latestLocation.longitude - pin.coordinate.longitude) <= rangeLon) ){
                    pin.atLocation = true
                    
                }else{
                    pin.atLocation = false
                }
            }
            
        }else{
            
            if((abs(latestLocation.latitude - destinationLoc.latitude) <= rangeVariable) && (abs(latestLocation.longitude - destinationLoc.longitude) <= rangeVariable) ){
                pinList[pinList.count-1].atLocation = true
                
            }else{
                pinList[pinList.count-1].atLocation = false
            }
            
        }
    }
    
    //=====================================UPDATE USER LOCATION =================================
    
    func UpdateUserLocation() {
        
        
        locationManager.startUpdatingLocation()
        sleep(1)
        
        GPSMapView.showsUserLocation = true
        
        locationManager.stopUpdatingLocation()
        
        
    }
    //=====================================UPDATE USER LOCATION =================================
    
    //=====================================TOURS=================================
    
    func guidedTourFunction(){
        sleep(2)
        if(tourNum <= maxTourNum){
            
            for index in 0...locationList.count - 1{
                
                
                if(locationList[index].guidedTour == tourNum){
                    
                    destinationLoc = locationList[index]
                    
                    let coordinate = CLLocationCoordinate2D(latitude: destinationLoc.latitude, longitude: destinationLoc.longitude)
                    
                    let pin = PinClass(coordinate: coordinate, name: destinationLoc.locationName, desc: destinationLoc.locationSubName, trivia: destinationLoc.trivia, image: destinationLoc.imageHyper,
                        range: destinationLoc.rangeVariable)
                    pinList.append(pin)
                    self.tourTextView.text = "Head to " + pin.pinName
                    self.GPSMapView.addAnnotation(pin.makeAnnotation())
                }
            }
        }
        
    }
    func freeRoamTourFunction(){
        
        for index in 0...locationList.count - 1{
            
            let destinationLoc = locationList[index]
            
            let coordinate = CLLocationCoordinate2D(latitude: destinationLoc.latitude, longitude: destinationLoc.longitude)
            
            let pin = PinClass(coordinate: coordinate, name: destinationLoc.locationName, desc: destinationLoc.locationSubName, trivia: destinationLoc.trivia, image: destinationLoc.imageHyper, range: destinationLoc.rangeVariable)
            
            pinList.append(pin)
            
            self.GPSMapView.addAnnotation(pin.makeAnnotation())
            self.tourTextView.text = "Head to Any Location"
        }
    }
    
    
    func randomGuidedTourFunction(){
        sleep(2)
        if(tourNum <= maxTourNum){
            var randomTourNum = Int(arc4random_uniform(UInt32(maxTourNum)) + 1)
            if(!randomDestination.isEmpty){
                
                while(randomDestination.contains(randomTourNum)){
                    randomTourNum = Int(arc4random_uniform(UInt32(maxTourNum)) + 1)
                }
                
            }
            randomDestination.append(randomTourNum)
            for index in 0...locationList.count - 1{
                
                if(locationList[index].guidedTour == randomTourNum){
                    
                    destinationLoc = locationList[index]
                    let coordinate = CLLocationCoordinate2D(latitude: destinationLoc.latitude, longitude: destinationLoc.longitude)
                    
                    let pin = PinClass(coordinate: coordinate, name: destinationLoc.locationName, desc: destinationLoc.locationSubName, trivia: destinationLoc.trivia, image: destinationLoc.imageHyper,
                        range: destinationLoc.rangeVariable)
                    
                    pinList.append(pin)
                    
                    self.tourTextView.text = "Head to " + pin.pinName
                    self.GPSMapView.addAnnotation(pin.makeAnnotation())
                }
            }
            
        }
    }
    
    //=====================================TOURS=================================
    
    //=====================================MAP VIEW/SEGUE =================================
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]){
        
        latestLocation = manager.location!.coordinate
        let location = CLLocationCoordinate2D(latitude: CLLocationDegrees(latestLocation.latitude), longitude: CLLocationDegrees(latestLocation.longitude))
        let span = MKCoordinateSpanMake(0.01, 0.01)
        let region = MKCoordinateRegion(center: location, span:span)
        GPSMapView.setRegion(region, animated: true)
        GPSMapView.showsUserLocation = true
        locationManager.stopUpdatingLocation()
        
    }
    
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView?{
        
        let identifier = "Location"
        var view: MKPinAnnotationView
        if let dequeuedView = mapView.dequeueReusableAnnotationView(withIdentifier: identifier) as? MKPinAnnotationView{
            dequeuedView.annotation = annotation
            view = dequeuedView
        } else if(annotation is MKUserLocation){
            view = MKPinAnnotationView(annotation: annotation, reuseIdentifier: "user location")
            view.pinTintColor = #colorLiteral(red: 0.3647058904, green: 0.06666667014, blue: 0.9686274529, alpha: 1)
        }
        else{
            view = MKPinAnnotationView(annotation: annotation, reuseIdentifier: identifier)
            view.canShowCallout = true
            view.calloutOffset = CGPoint(x: -5, y: 5)
            let button = (UIButton(type: .detailDisclosure))
            button.isHidden = true
            let buttonView = button as UIView
            view.rightCalloutAccessoryView = buttonView
            
        }
        return view
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any!) {
        if (segue.identifier == "DetailSegue") {
            let dest = segue.destination as! DetailsViewController
            dest.Location = selectedLocation
            dest.endTour = endTour
        }
        
    }
    
    
    func mapView(_ mapView: MKMapView, annotationView view: MKAnnotationView, calloutAccessoryControlTapped control: UIControl){
        if control == view.rightCalloutAccessoryView{
            
            for pin in pinList {
                if(pin.pinName == (view.annotation?.title)! && pin.atLocation == true){
                    
                    if(TourType == 1){
                        tourNum = tourNum + 1
                        pinList.popLast()
                        mapView.removeAnnotation(view.annotation!)
                        if(tourNum > maxTourNum){
                            endTour = true
                            updateLocationTimer.invalidate()
                        } else{
                            guidedTourFunction()
                        }
                    }else if(TourType == 3){
                        tourNum = tourNum + 1
                        pinList.popLast()
                        mapView.removeAnnotation(view.annotation!)
                        if(tourNum > maxTourNum){
                            endTour = true
                            updateLocationTimer.invalidate()
                        }
                        randomGuidedTourFunction()
                        
                    }
                    selectedLocation = pin
                    
                    self.performSegue(withIdentifier: "DetailSegue", sender: self)
                    
                }
            }
            
        }
        
    }
    
    //=====================================MAP VIEW/SEGUE =================================
    
    //====================================PARSER=================================
    func parser(){
        
        let urlAsStringMain = "https://spreadsheets.google.com/feeds/list/1Q1EE8aULP4ZQaQrvq3IatJAjiPhOPuGTXH7TUdTvor4/od6/public/basic?alt=json"
        
        let url = URL(string: urlAsStringMain)
        let urlSession = URLSession.shared
        let task = urlSession.dataTask(with: url!, completionHandler: {data, response, error -> Void in
            
            if (error != nil){
                print(error!.localizedDescription)
                
            }
            do{
                
                if let jsonResult = try JSONSerialization.jsonObject(with: data!, options: JSONSerialization.ReadingOptions.mutableContainers) as? NSDictionary{
                    
                    let feed = jsonResult["feed"] as? NSDictionary // Json Value of 'feed' which is the RSS in the data.
                    let entry = feed?["entry"] as? NSArray // Json Value of 'entry' which is the RSS in the data.
                    
                    
                    for item in entry!{
                        let dict = item as? NSDictionary
                        let content = dict?["content"] as? NSDictionary
                        
                        let info = content?["$t"] as? String
                        
                        let fullNameArr = info?.components(separatedBy: ", ")
                        
                        
                        let loc =  LocationClass()
                        for name in fullNameArr! {
                            let itemArr = name.components(separatedBy: ": ")
                            
                            
                            if( itemArr[0] == "name"){
                                loc.locationName = itemArr[1]
                                
                            } else if( itemArr[0] == "subname"){
                                loc.locationSubName = itemArr[1]
                                
                            }else if( itemArr[0] == "latitude"){
                                loc.latitude = Double(itemArr[1])!
                                
                            }else if( itemArr[0] == "longitude"){
                                loc.longitude = Double(itemArr[1])!
                                
                            }else if (itemArr[0] == "locationrange"){
                                
                                loc.rangeVariable = Double(itemArr[1])!/Double(5280)
                                
                                
                            }
                            
                            else if( itemArr[0] == "guidedtour"){
                                loc.guidedTour = Int(itemArr[1])!
                                if(loc.guidedTour > self.maxTourNum){
                                    self.maxTourNum = loc.guidedTour
                                }
                                
                            }else if( itemArr[0] == "imagehyperlinks"){
                                
                                
                                if itemArr[1].range(of: "; ") != nil{
                                    let imageHyper = (itemArr[1]).components(separatedBy: "; ")
                                    loc.imageHyper = imageHyper
                                   
                                    
                                }else{
                                    
                                    loc.imageHyper = [itemArr[1]]
                                }
                                
                            }else if( itemArr[0] == "trivia"){
                                
                                
                                if itemArr[1].range(of: "; ") != nil{
                                    let trivia = (itemArr[1]).components(separatedBy: "; ")
                                    loc.trivia = trivia
                                    
                                    
                                }else{
                                    
                                    loc.trivia = [itemArr[1]]
                                }
                            }
                        }
                        self.locationList.append(loc)
                        
                    }
                }
                
            }
                
            catch{
                print("has Error")}
            
        })
        
        task.resume()
        sleep(2)
           
    }
    //====================================PARSER=================================
    
    func back(sender: UIBarButtonItem){
        
        updateLocationTimer.invalidate()//Timer Stop
        back = true
        
        _ = navigationController?.popViewController(animated: true)
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
}



