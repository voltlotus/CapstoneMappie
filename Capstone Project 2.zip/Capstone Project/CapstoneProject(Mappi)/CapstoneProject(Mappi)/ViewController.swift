//
//  ViewController.swift
//  CapstoneProject(Mappi)
//
//  Created by hayden rusk on 10/16/16.
//  Copyright © 2016 BSUCS320. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation



class ViewController: UIViewController, MKMapViewDelegate, CLLocationManagerDelegate {

    
    @IBAction func ResetLocationButton(_ sender: AnyObject) {
            
        locationManager.startUpdatingLocation()
        
        GPSMapView.showsUserLocation = true
        
        locationManager.stopUpdatingLocation()
        
        let newLatitude: Float = Float(latitude_text)!
        let newLongitude: Float = Float(longitude_text)!
             
        let location = CLLocationCoordinate2D(latitude: CLLocationDegrees(newLatitude), longitude: CLLocationDegrees(newLongitude))
        let span = MKCoordinateSpanMake(0.01, 0.01)
        let region = MKCoordinateRegion(center: location, span:span)
        GPSMapView.setRegion(region, animated: true)
        GPSMapView.showsUserLocation = true
        
        
    }
   
    @IBOutlet weak var GPSMapView: MKMapView!
    
    var locationManager: CLLocationManager = CLLocationManager()
    var startLocation: CLLocation!
    
    var longitude_text = ""
    var latitude_text = ""
    
    
    var userLatitude = 40.20370
    var userLongitude = -85.40797
    
    var bellTowerLat = 40.20370
    var bellTowerLong = -85.40797
    
    let bellTowerAnnotation = MKPointAnnotation()
    
    var latitudeList: [Double] = [40.20370, 40.20320]
    var longitudeList: [Double] = [-85.40797, -85.40667]
    var descList: [String] = ["BSU", "BSU"]
    var nameList: [String] = ["Bell Tower", "Bracken Library"]
    
    var pinList: [PinClass] = []
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.GPSMapView.delegate = self
        
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.delegate = self
        locationManager.requestWhenInUseAuthorization()
        locationManager.startUpdatingLocation()
        startLocation = nil
        
        
        let location = CLLocationCoordinate2D(latitude: userLatitude, longitude: userLongitude)
        let span = MKCoordinateSpanMake(0.01, 0.01)
        let region = MKCoordinateRegion(center: location, span:span)
        GPSMapView.setRegion(region, animated: true)
        GPSMapView.showsUserLocation = true
        
        
        /*let bellTowerLocation = CLLocationCoordinate2D(latitude: bellTowerLat, longitude: bellTowerLong)
        bellTowerAnnotation.coordinate = bellTowerLocation
        bellTowerAnnotation.title = "BallState Bell Tower"
        bellTowerAnnotation.subtitle = "Click for more Info"
        
 
        GPSMapView.addAnnotation(bellTowerAnnotation)
        */
        for index in 0...(nameList.count - 1){
            var coordinate = CLLocationCoordinate2D(latitude: latitudeList[index], longitude: longitudeList[index])
            
            pinList.append(PinClass(coordinate: coordinate, name: nameList[index], desc: descList[index]))
            
            
            GPSMapView.addAnnotation(pinList[index].makeAnnotation())
        }
        
        //GPSMapView.reloadInputViews()
        
      
        
        
   
    }
    
    
    func locationManager(_ manager: CLLocationManager!, didUpdateLocations locations: [CLLocation]!){
        
        var latestLocation: CLLocation = locations[locations.count - 1]
        latitude_text = String(format: "%.4f", latestLocation.coordinate.latitude)
        longitude_text = String(format: "%.4f", latestLocation.coordinate.longitude)
        
        print(latitude_text)
        print(longitude_text)
        
        
        if startLocation == nil{
            startLocation = latestLocation as! CLLocation
        }
        
        var distanceBetween: CLLocationDistance = latestLocation.distance( from: startLocation)
        
        var distance_text = String(format: "%.2f", distanceBetween)
        
        
        
        
        
    }
    func locationManager(_ manager: CLLocationManager, didfailWithError error: NSError){
        print("eroooroejrelajiejflaj")
    }
    
    
    func mapView(_ mapView: MKMapView!, viewFor annotation: MKAnnotation!) -> MKAnnotationView!{
        
        
        let identifier = "BallState Bell Tower"
        var view: MKPinAnnotationView
        if let dequeuedView = mapView.dequeueReusableAnnotationView(withIdentifier: identifier) as? MKPinAnnotationView{
            dequeuedView.annotation = annotation
            view = dequeuedView
        }else{
            view = MKPinAnnotationView(annotation: annotation, reuseIdentifier: identifier)
            view.canShowCallout = true
            view.calloutOffset = CGPoint(x: -5, y: 5)
            let button = (UIButton(type: .detailDisclosure))
            button.isHidden = true
            let buttonView = button as UIView
            view.rightCalloutAccessoryView = buttonView
            
            
        }
        return view
    }
    
    func mapView(_ mapView: MKMapView, annotationView view: MKAnnotationView, calloutAccessoryControlTapped control: UIControl){
        if control == view.rightCalloutAccessoryView{
          
            
            self.performSegue(withIdentifier: "BellTowerSegue", sender: self)
            
        }
        
         print("---button success---")
    }
    
   
    
    
    
    
    
   
    
 
    
    func requestWhenInUseAuthorization(){
        //Look up videos on to get an authorization.
        
        
        
        
            }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

