//
//  PinClass.swift
//  CapstoneProject(Mappi)
//
//  Created by hayden rusk on 11/1/16.
//  Copyright © 2016 BSUCS320. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation

class PinClass: NSObject, MKAnnotation {
    var myCoordinate: CLLocationCoordinate2D
    
    //var pinLatitude = 0
    //var pinLongitude = 0
    
    
    var pinName = ""
    var pinDesc = ""
    var annotation = MKPointAnnotation()
    
    
    
    init(coordinate: CLLocationCoordinate2D, name: String, desc: String ){
        
        pinName = name
        pinDesc = desc
        
        myCoordinate = coordinate
        
        
        
    }
    var coordinate: CLLocationCoordinate2D{
        return myCoordinate
    }
    func makeAnnotation() -> MKPointAnnotation{
        
        annotation.coordinate = coordinate
        annotation.title = pinName
        annotation.subtitle = pinDesc
        
        
        return annotation
        
        
    }
}


/*
 var locationManager: CLLocationManager = CLLocationManager()
 var startLocation: CLLocation!
 
 var longitude_text = ""
 var latitude_text = ""
 
 
 var userLatitude = 40.20370
 var userLongitude = -85.40797
 
 var bellTowerLat = 40.20370
 var bellTowerLong = -85.40797
 
 let bellTowerAnnotation = MKPointAnnotation()
 
 
 
 
 let bellTowerLocation = CLLocationCoordinate2D(latitude: bellTowerLat, longitude: bellTowerLong)
 bellTowerAnnotation.coordinate = bellTowerLocation
 bellTowerAnnotation.title = "BallState Bell Tower"
 bellTowerAnnotation.subtitle = "Click for more Info"
 
 
 GPSMapView.addAnnotation(bellTowerAnnotation)
 

 
 
 
 */
